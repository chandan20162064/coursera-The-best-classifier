# coursera-ML-The-best-classifier
The capstone project for my machine learning course with python.
